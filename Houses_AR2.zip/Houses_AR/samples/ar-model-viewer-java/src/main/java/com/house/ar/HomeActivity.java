package com.house.ar;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;
import java.util.List;

public class HomeActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    ModelAdapter modelAdapter;
    List<Item> items = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        recyclerView = findViewById(R.id.recyclerView);

        items.add(new Item(R.drawable.small_home, "small_home.glb"));
        items.add(new Item(R.drawable.medium_home, "medium_home.glb"));
        items.add(new Item(R.drawable.large_home, "large_home.glb"));
        items.add(new Item(R.drawable.penthouse, "penthouse.glb"));

        GridLayoutManager gridLayoutManager = new GridLayoutManager(getApplicationContext(),2);
        recyclerView.setLayoutManager(gridLayoutManager);
        modelAdapter =new ModelAdapter((ArrayList<Item>) items,HomeActivity.this);
        recyclerView.setAdapter(modelAdapter);
    }
}